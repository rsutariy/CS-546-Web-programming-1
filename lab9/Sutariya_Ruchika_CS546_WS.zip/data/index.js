const user = require("./user");

module.exports = {
    user: user
};